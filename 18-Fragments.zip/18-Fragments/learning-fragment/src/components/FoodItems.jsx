import Item from "./Item";
const FoodItems = () => {
  let foodItems = ["Dal", "Green Vegetable", "Roti", "Salad", "Milk"];
  return (
    <ul className="list-group">
      {foodItems.map((item) => (
        <Item key={item} foodItems={item}></Item>
      ))}
    </ul>
  );
};
export default FoodItems;
