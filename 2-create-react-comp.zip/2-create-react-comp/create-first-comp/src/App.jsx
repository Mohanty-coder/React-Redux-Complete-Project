import {KgButton} from "./KgButton";
import Button from "./KgButton";
import Hello from "./Hello";
import Random from "./Random";


function App(){
  return (
  <div>
    <h1>This is the KgButton</h1>
    <KgButton></KgButton>
    <h2>This is the Button</h2>
    <Button></Button>
    <h3>This is the Hello Button</h3>
    <Hello></Hello>
    <Random style={{'background-color':'#776891'}}></Random>
    <Random></Random>
    <Random></Random>
  </div>
  );
}
export default App;