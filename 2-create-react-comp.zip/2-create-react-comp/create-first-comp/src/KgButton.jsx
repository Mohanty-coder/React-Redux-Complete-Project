export function KgButton(){
    return <button>Like this Video</button>
}
export default function Button(){
    return <button>Next Video</button>
}
